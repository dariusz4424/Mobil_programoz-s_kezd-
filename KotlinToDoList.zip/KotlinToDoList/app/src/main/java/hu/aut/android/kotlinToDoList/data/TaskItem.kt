package hu.aut.android.kotlinToDoList.data

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.PrimaryKey
import java.io.Serializable

/*db-hez a tábla és mezői*/
@Entity(tableName = "taskitem")
data class TaskItem(@PrimaryKey(autoGenerate = true) var itemId: Long?,
                    @ColumnInfo(name = "Task") var task: String,
                    @ColumnInfo(name = "Task_Description") var taskDescription: String,
                    @ColumnInfo(name = "Comment") var comment: String,
                    @ColumnInfo(name = "Done") var done: Boolean
) : Serializable
