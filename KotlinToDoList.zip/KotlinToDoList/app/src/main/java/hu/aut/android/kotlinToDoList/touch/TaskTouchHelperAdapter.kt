package hu.aut.android.kotlinToDoList.touch

interface TaskTouchHelperAdapter {

    fun onItemDismissed(position: Int)

    fun onItemMoved(fromPosition: Int, toPosition: Int)
}