package hu.aut.android.kotlinToDoList.data

import androidx.lifecycle.LiveData
import androidx.room.*

@Dao
interface TaskItemDAO {

    @Query("SELECT * FROM taskitem")
    fun findAllItems(): LiveData<List<TaskItem>>

    @Insert
    fun insertItem(item: TaskItem): Long

    @Delete
    fun deleteItem(item: TaskItem)

    @Update(onConflict = OnConflictStrategy.REPLACE)
    fun updateItem(item: TaskItem)

}
