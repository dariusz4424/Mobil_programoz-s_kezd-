package hu.aut.android.kotlinToDoList.adapter

import android.annotation.SuppressLint
import android.content.Context
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.RecyclerView
import hu.aut.android.kotlinToDoList.MainActivity
import hu.aut.android.kotlinToDoList.adapter.TaskAdapter.ViewHolder
import hu.aut.android.kotlinToDoList.data.AppDatabase
import hu.aut.android.kotlinToDoList.data.TaskItem
import hu.aut.android.kotlinToDoList.databinding.RowItemBinding
import hu.aut.android.kotlinToDoList.touch.TaskTouchHelperAdapter
import kotlinx.android.synthetic.main.row_item.view.*
import java.util.*
import kotlin.concurrent.thread
/*Az Adapter objektum hídként működik az AdapterView és az adott nézet mögöttes adatai között.
 Az Adapter hozzáférést biztosít az adatelemekhez.
  Az Adapter felelős azért is, hogy nézetet készítsen az adatkészlet minden eleméhez.

 */
class TaskAdapter(var context: Context) :
    ListAdapter<TaskItem, ViewHolder>(TaskDiffCallback()), TaskTouchHelperAdapter {
    /*új elem megjelenítésekor hívódik meg*/
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val binding = RowItemBinding
            .inflate(LayoutInflater.from(parent.context), parent, false)
        return ViewHolder(binding)
    }
    /*adott pozíciójú elem frissítése*/
    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        /*adott pozíciójú elem lekérése*/
        val item = getItem(position)
        holder.bind(item)

        with(holder) {
            /*delete gomb eseménykezelő*/
            binding.btnRemove.setOnClickListener {
                thread {
                    /*delete meghívása*/
                    AppDatabase.getInstance(context).taskItemDao().deleteItem(item)
                }
            }
            /*edit gomb eseménykezelő, mainactivity-ben edit dialógus meghívása*/

            binding.btnEdit.setOnClickListener {
                (holder.itemView.context as MainActivity).showEditItemDialog(
                    item
                )
            }
            /*checkbox eseménykezelő, lekédezzük, hogy be van-e ikszelve, és firssítjük a db-t a dao-val*/

            binding.cbCompleted.setOnClickListener {
                item.done = binding.cbCompleted.isChecked
                thread {
                    AppDatabase.getInstance(context).taskItemDao().updateItem(item)
                }
            }
        }
    }

    override fun onItemDismissed(position: Int) {
        thread {
            AppDatabase.getInstance(context).taskItemDao().deleteItem(getItem(position))
        }
    }

    override fun onItemMoved(fromPosition: Int, toPosition: Int) {
        notifyItemMoved(fromPosition, toPosition)
    }

    inner class ViewHolder(val binding: RowItemBinding) : RecyclerView.ViewHolder(binding.root) {
        fun bind(item: TaskItem) {
            binding.item = item
        }
    }

}

class TaskDiffCallback : DiffUtil.ItemCallback<TaskItem>() {
    override fun areItemsTheSame(oldItem: TaskItem, newItem: TaskItem): Boolean {
        return oldItem.itemId == newItem.itemId
    }

    @SuppressLint("DiffUtilEquals")
    override fun areContentsTheSame(oldItem: TaskItem, newItem: TaskItem): Boolean {
        return oldItem == newItem
    }
}